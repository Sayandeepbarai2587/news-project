-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2021 at 04:11 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `numbering` int(11) NOT NULL,
  `category_id` varchar(40) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`numbering`, `category_id`, `category_name`, `post`) VALUES
(19, '21/06/2021-:-08:18:46-:-6093973590', 'Technology', 3),
(20, '21/06/2021-:-08:18:52-:-1464948689', 'Sports', 3),
(21, '21/06/2021-:-08:18:57-:-84701333', 'Health', 3),
(22, '21/06/2021-:-08:46:22-:-1705730436', 'Science', 3),
(23, '21/06/2021-:-09:20:18-:-9610164623', 'Business', 6),
(25, '22/06/2021-:-03:18:59-:-8642301181', 'demo', 0),
(24, '22/06/2021-:-10:21:19-:-3449234041', 'World', 2);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `numbering` int(11) NOT NULL,
  `post_id` varchar(40) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(40) DEFAULT NULL,
  `post_date` varchar(50) DEFAULT NULL,
  `author` varchar(40) DEFAULT NULL,
  `post_img` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`numbering`, `post_id`, `title`, `description`, `category`, `post_date`, `author`, `post_img`) VALUES
(13, '21/06/2021~:~08:28:35~:~2319383039', 'HP Chromebook 11a review: Great for students, not so for professionals', 'The HP Chromebook 11a is among the most affordable laptops you can buy in 2021 but the use case is best limited to student requirements. Here’s our review.\r\nA new world order is implemented post the COVID-19 pandemic and digital is now the only way forward. With more COVID waves incoming, it is likely to stay the same. This translates to horror for burdened middle-class parents but a victory for tech brands; the latter now able to sell horrendous cheap Android tablets at higher prices than before. HP thinks it can play the saviour hero here with its Chromebook 11a laptop.', '21/06/2021-:-08:18:46-:-6093973590', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '22-06-2021_08-04-06__40358__HP.jpg'),
(14, '21/06/2021~:~08:30:22~:~4078494801', 'Samsung Galaxy M32 launched, features 90Hz AMOLED display and 6,000mAh battery', 'As an introductory offer, consumers can avail an instant cashback worth Rs 1,250 with ICICI cards, bringing down the price of the 4GB+64GB variant to Rs 13,749 and 6GB+128GB variant to Rs 15,749.\r\nSamsung on Monday launched Galaxy M32 with segment-best 6.4-inch FHD+ Super AMOLED display and smooth 90Hz refresh rate in India that starts from Rs 14,999.', '21/06/2021-:-08:18:46-:-6093973590', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_08-30-22__69760__SamsungM32.jpg'),
(15, '21/06/2021~:~08:35:46~:~7166405652', 'iOS bug making iPhones break if they connect to this WiFi network', 'A recent iOS bug is causing trouble if iPhone users connect to a WiFi network with a specialised name. It can disable an iPhone\'s ability to connect to Wi-Fi hotspots if it attempts to initially connect to a hotspot with a specific name that breaks the function.\r\nSecurity researcher Carl Schou gave a personal Wi-Fi hotspot a name comprising special characters -- \"%p%s%s%s%s%n\". On trying to connect to the hotspot, Schou discovered the iPhone simply couldn\'t connect to it at all, and later discovered that it disabled Wi-Fi connectivity completely on the device, AppleInsider reported.\r\nAttempts to connect to other hotspots failed, with the issue continuing to manifest after changing the hotspot\'s SSID and rebooting the iPhone, according to BleepingComputer.\r\nThe issue was also confirmed by others testing out the same SSID name separately.\r\nTests also point to it being a problem just with iPhones, as Android devices appear to connect to the unusually-named access point without issue.\r\nOther researchers examining the phenomena believe it is an issue with input parsing, in which the percentage sign at the start may be misinterpreted by iOS as a string-format specifier, and the characters following may be a variable or a command rather than plain text.\r\nTo fix the problem on affected iPhones, users have to reset their iOS network settings.\r\nThe discovery is reminiscent of text messages that contained strings and special characters that could cause problems for iPhones and loads, the report said. For example, April\'s \"text bomb\" forced iPhones to crash if a flag emoji and a specific Sindhi language character were viewed in an incoming notification, it added.', '21/06/2021-:-08:18:46-:-6093973590', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '21-06-2021_08-35-46__8938__iphone12.jpg'),
(16, '21/06/2021~:~08:38:50~:~3750655448', 'BCCI to form committee to compensate domestic cricketers', 'The Board of Control for Cricket in India (BCCI) has decided to form a committee to compensate for the loss of income for the domestic cricketers, who have been badly affected by the pandemic in the country. The BCCI has also decided to help India\'s Olympic contingent, both being initiatives of BCCI secretary Jay Shah who called an impromptu Apex Council meeting on Sunday (June 20).\r\nThe meeting, which completed around 6 pm on Sunday, adopted both the resolutions.\r\nThe meeting\'s most important agenda was to decide on ways to compensate the domestic cricketers, who have been rendered dormant because of the national and global pandemic situation and thereby have lost the main source of their income, which is domestic cricket.', '21/06/2021-:-08:18:52-:-1464948689', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '21-06-2021_08-38-50__38357__bcci.jpg'),
(17, '21/06/2021~:~08:43:00~:~4519226381', 'Can the Indian hockey team end 41-year medal drought at Tokyo Olympics? ', 'India, then a colony under Great Britain, had decided to field a team in field hockey in the 1928 Amsterdam Olympics for the first time. In their preparation for the Olympic Games, they played several leading clubs of London and beat them before facing the England national hockey team. In fear of losing to a colony at the Olympic stage, the defending champions Great Britain decided to withdraw from the 1928 Amsterdam Olympics. Such stories bear the testament of India\'s reign over world hockey, which lasted for six decades.', '21/06/2021-:-08:18:52-:-1464948689', '21 Jun, 2021', '20/06/2021-10:00:04--2808095767', '21-06-2021_08-43-43__96221__indai.jpg'),
(18, '21/06/2021~:~08:50:01~:~5856285315', 'Asteroid 16 Psyche believed worth USD 10000 quadrillions could be a rubber pile?', 'New research published in the journal The Planetary Science, reveals the contradictory properties of the asteroid 16 Psyche which was earlier supposed to be a dense asteroid made of  97% metal consisting of iron, gold and nickel.\r\nWashington: Psyche 16, the asteroid which was believed to be worth $ 10,000 Quadrillion because of its metal content, may not worth that huge amount of money at all.\r\nAs the new revelations suggest, the asteroid may be a porous pile of rubber that was earlier supposed to contain 97% dense metal like iron, gold, and nickel.\r\nAccording to new research published in The Planetary Science journal led by undergraduate student David Cantillo at the University of Arizona, 16 Psyche is 82.5% metal, 7% low-iron pyroxene, and 10.5% carbonaceous chondrite that was likely delivered by impacts from other asteroids. \r\nCantillo and his collaborators estimate that 16 Psyche\'s bulk density, also known as porosity, which refers to the empty space is found within its body is around 35%.\r\n\"That drop in metallic content and bulk density is interesting because it shows that 16 Psyche is more modified than previously thought,\" Cantillo said.', '21/06/2021-:-08:46:22-:-1705730436', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_08-50-01__97490__nasa.jpg'),
(19, '21/06/2021~:~08:54:14~:~7956815246', 'Earth’s energy imbalance doubled in 14 years: NASA', 'Raising an alarm over human-caused climate change, NASA-led research has revealed that the amount of heat trapped by Earth’s land, ocean and atmosphere has doubled over the course of only 14 years.\r\nScientists at NASA and the National Oceanic and Atmospheric Administration (NOAA) in the US found that Earth’s energy imbalance approximately doubled during the 14-year period from 2005 to 2019.\r\nTo reach this conclusion, scientists compared data from two independent measurements — NASA’s Clouds and the Earth’s Radiant Energy System (CERES) and data from a global array of ocean floats called Argo that enable an accurate estimate of the rate at which the world’s oceans are heating up.\r\n“The two very independent ways of looking at changes in Earth’s energy imbalance are in really, really good agreement, and they’re both showing this very large trend, which gives us a lot of confidence that what we’re seeing is a real phenomenon and not just an instrumental artifact,” said Norman Loeb, lead author and principal investigator for CERES at NASA.\r\n“The trends we found were quite alarming in a sense,” he said in a study published in the journal Geophysical Research Letters.\r\nIncreases in emissions of greenhouse gases such as carbon dioxide and methane due to human activity trap heat in the atmosphere, capturing outgoing radiation that would otherwise escape into space.\r\nThe warming drives other changes, such as snow and ice melt, and increased water vapour and cloud changes that can further enhance the warming.\r\n“Earth’s energy imbalance is the net effect of all these factors,” the findings showed. The study found that the doubling of the imbalance is partially the result of an increase in greenhouse gases due to human activity, also known as anthropogenic forcing, along with increases in water vapour, are trapping more outgoing longwave radiation, further contributing to Earth’s energy imbalance.\r\nAdditionally, the related decrease in clouds and sea ice lead to more absorption of solar energy.\r\n“It’s likely a mix of anthropogenic forcing and internal variability, and over this period, they’re both causing warming, which leads to a fairly large change in Earth’s energy imbalance. The magnitude of the increase is unprecedented,” Loeb warned.\r\nUnless the rate of heat uptake subsides, greater changes in climate than are already occurring should be expected.\r\n“Observing the magnitude and variations of this energy imbalance are vital to understanding Earth’s changing climate,” said Gregory Johnson, physical oceanographer at NOAA.', '21/06/2021-:-08:46:22-:-1705730436', '21 Jun, 2021', '20/06/2021-12:08:42--6392356527', '21-06-2021_08-54-14__81609__nasa1.jpg'),
(20, '21/06/2021~:~08:57:25~:~1005734321', 'Dimming of Betelgeuse: Here’s Why the Glow of One of Brightest Stars Faded', 'Betelgeuse, once said to be the ninth most luminous star in the sky, started dimming rapidly in December 2019. Even though Betelgeuse was always a “variable” star, meaning its brightness would fluctuate, by February 2020 it had reported a loss of nearly two-thirds of its brightness. This made astronomers wonder if it was soon going to explode as a supernova. A team of scientists has found the reason behind the rapid rate at which the star has been growing dim. They said that the dimming wasn\'t an indication of an explosion of Betelgeuse, known as the gleaming right shoulder of the constellation Orion.\r\nThe team of scientists said that the most likely explanation could be a giant cloud of dust making the star seem dimmer to those on Earth.\r\nThe study titled ‘A dusty veil shading Betelgeuse during its Great Dimming\' has been published in the Nature journal. The authors said in the introduction of the paper that observations and modelling support a scenario in which “a dust clump formed recently in the vicinity of the star”. The authors have, however, added that some red supergiants, such as the one Betelgeuse is, show “little or no sign of their impending core collapse, years to weeks before it happens”.\r\nBut they explained that while the current mass-loss behaviour of the giant star, almost 15 times that of the Sun, doesn\'t show any sign of its impending explosion, it could explode without warning. Following their research, the authors could figure four scenarios explaining the Great Dimming of Betelgeuse.\r\nThe first, they said could be a (potentially local) decrease in the effective temperature of the star, making it fainter. The second, according to them, was an occultation by newly formed dust. Third, an occultation by dust transiting in front of the star and forth a change in the angular diameter.\r\nThey then check each scenario against their observations and ruled out the third and fourth scenarios straightaway. \"Our findings suggest that a component of mass loss from red supergiants is inhomogeneous, linked to a very contrasted and rapidly changing photosphere,\" they said.\r\nHaving said that, there\'s no denying that Betelgeuse will go supernova someday, if not immediately. Miguel Montargès, an astrophysicist at Catholic University-Leuven in Belgium, and the lead author of the paper, had in 2019 said: \"But I\'m not holding my breath for it.\"\r\nThe same year it was reported that though the supergiant was nearing the end of its life span, it could still be as long as 100,000 years before the star begins its death throes.', '21/06/2021-:-08:46:22-:-1705730436', '21 Jun, 2021', '20/06/2021-12:08:42--6392356527', '21-06-2021_08-57-25__81462__sun.jpg'),
(21, '21/06/2021~:~09:01:13~:~8899877525', 'Coronavirus vaccination: Is there a need for a COVID booster shot? Here\'s what WHO has to say', 'Given the emergence of multiple new SARs-COV-2 variants, health authorities are extremely concerned about vaccine efficacy. The Delta variant, which is a possible driving force of the second wave of COVID-19, is said to be highly infectious and transmissible, which can also cause breakthrough infections.\r\n\r\nAmidst all this chaos, many wonder whether the two vaccine doses are enough to fight the deadly virus. That said, scientists and doctors are currently in a bid to find out whether a COVID booster shot is required for people who have received both their COVID vaccines and are \'fully vaccinated\'.', '21/06/2021-:-08:18:57-:-84701333', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-01-13__93968__covid.jpg'),
(22, '21/06/2021~:~09:06:01~:~7927624384', 'Genetic cause of intellectual disabilities, neurodevelopmental disorders discovered: Study', 'A new gene that might be linked to certain intellectual disabilities and neurodevelopmental disorders was identified by researchers at the University of Maryland School of Medicine (UMSOM).\r\nOntario: During a new study, researchers from the University of Maryland School of Medicine (UMSOM) identified a new gene that might be linked to certain intellectual disabilities and neurodevelopmental disorders. The findings were recently published in the American Journal of Human Genetics. Researchers of the study believe that finding genes involved in certain types of developmental disorders, provides an important first step in determining the cause of these disorders and ultimately in developing potential therapies for treating them.\r\nAbout 3 per cent of the world\'s population has an intellectual disability. Up to half, the cases are due to genetics, however, because many thousands of genes contribute to brain development, it has been difficult to identify the specific cause for each patient. Once the researchers identified the gene, they worked with collaborators to give clinical diagnoses to 10 other families around the world, who had relatives with this condition. The researchers also used zebrafish to show the gene\'s role in development and survival, demonstrating its importance in helping the brain\'s neurons function properly.', '21/06/2021-:-08:18:57-:-84701333', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-08-26__13428__dna.jpg'),
(23, '21/06/2021~:~09:11:49~:~6958363464', 'Increased screen time during Covid related with mental distress in young adults: Study', 'The increase in time spent viewing entertainment on a screen both prior to and during the pandemic was associated with a boost in anxiety scores.\r\nAccording to a new research led by investigators at the Saint James School of Medicine, an increase in screen time among young adults during the Covid-19 pandemic can be correlated with a rise in pandemic-related distress.\r\nStudents scored higher than non-students in pandemic-related distress. Surprisingly, the results showed no association of depression with screen time use, despite such associations having been found in previous research. The research will be presented at World Microbe Forum, taking place online June 20-24.\r\n\"This study highlights that the pandemic did not simply affect people physically, but emotionally and mentally, with various groups being impacted to a greater extent than others,\" said Michelle Wiciak, the presenting author on the research, M.D. candidate at Saint James School of Medicine. \"It reiterates that there is an increased need for mental health support during disastrous times.\"', '21/06/2021-:-08:18:57-:-84701333', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '21-06-2021_09-11-49__77928__a.jpg'),
(24, '21/06/2021~:~09:18:45~:~224791040', 'ISL vs MUL Match Prediction Who Will Win Today PSL 2021 Qualifier', 'Islamabad United will take on Multan Sultans at Sheikh Zayed Stadium, Abu Dhabi, in the 30th Match of Pakistan Super League 2021 on Monday 21st June 2021. Keep reading to find out ISL vs MUL Match Prediction Who Will Win Today PSL 2021 Qualifier.', '21/06/2021-:-08:18:52-:-1464948689', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '21-06-2021_09-18-45__99902__cr.jpg'),
(25, '21/06/2021~:~09:22:38~:~6780108984', 'Airtel and TCS announce collaboration for \'Made in India\' 5G network', 'Indian telecommunications firm Bharti Airtel, on Monday, announced a strategic partnership with IT services firm Tata Consultancy Services (TCS) for implementing 5G broadband network solutions in India.\r\nTata Group has developed a ‘state-of-the-art’ O-RAN (Open Radio Access Network) based Radio and NSA/SA Core and has integrated a totally indigenous telecom stack, leveraging the Group capabilities and that of its partners. This will be available for commercial development starting January 2022.\r\nAs per the partnership, Airtel will pilot this indigenous solution during its 5G rollout. The pilot will begin in January 2022 as per Government of India guidelines.\r\n“With its world-class technology ecosystem and talent pool, India is well-positioned to build groundbreaking solutions and applications for the world. This will also provide a massive boost to India becoming an innovation and manufacturing destination,” said Gopal Vittal, MD and CEO (India and South Asia) at Bharti Airtel.\r\nThe 5G solutions, once commercially proven in Airtel’s diverse and brownfield network will open export opportunities for India, which is now the second-largest telecom market in the world after China.\r\nAirtel is a Board member of the O-RAN Alliance and is committed to explore and implement O-RAN based networks in India. Earlier this year, Airtel became the first telecom company in India to demonstrate 5G over its LIVE network in Hyderabad. The Company has started 5G trials in major cities using spectrum allocated by the Department of Telecom.\r\nOther Indian telecom players such as Reliance Jio have also commenced 5G trials, even as experts believe that the prolonged second wave of the Covid-19 pandemic will delay the countrywide rollout of the technology.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-22-38__66478__Airtel.jpg'),
(26, '21/06/2021~:~09:25:08~:~1372583505', 'India Received $64 Billion FDI In 2020, Fifth Largest In World: UN', 'India received $64 billion in Foreign Direct Investment in 2020, the fifth largest recipient of inflows in the world, according to a UN report which said the COVID-19 second wave in the country weighs heavily on the country\'s overall economic activities but its strong fundamentals provide \"optimism\" for the medium term.\r\nThe World Investment Report 2021 by the UN Conference on Trade and Development (UNCTAD), released Monday, said global FDI flows have been severely hit by the pandemic and they plunged by 35 per cent in 2020 to $1 trillion from $1.5 trillion the previous year.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-25-08__18298__rupee-vs-dollar.jpg'),
(27, '21/06/2021~:~09:30:36~:~3683012160', 'Hyundai Creta SX Executive launched: Cheaper by Rs. 78,000 & available in petrol & diesel', 'Hyundai Creta SX Executive Launched: Cheaper By Rs. 78,000 & Available In Petrol & Diesel\r\nIn a bid to consolidate Creta’s segment-best sales numbers, Hyundai has launched a new mid-level SX Executive trim in the Indian market. Hyundai has launched the trim with both petrol and diesel engine options but only a manual transmission option is available with the trim.\r\nThe Creta SX Executive is positioned between the S and the SX trim levels. Compared to the SX trim prices, the Creta SX Executive is about Rs 78,000 more affordable than the standard version. Here are the prices of the Creta SX manual and the newly launched Creta SX Executive.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-32-57__60893__Hyundai-Creta.jpg'),
(28, '21/06/2021~:~09:36:36~:~4634969723', 'Authum Investment to acquire all assets of Reliance Home Finance, shares up 2%', 'Share prices of Reliance Home Finance and Authum Investment & Infrastructure rose 5 percent and 2 percent respectively in early trade on June 21 after the latter emerged as the successful highest bidder for acquisition of all assets of Reliance Home Finance.\r\nShares of Authum Investment & Infrastucture touched a 52-week high of Rs 585.90 and Reliance Home Finance touched a 52-week high of Rs 5.98.\r\nThe Letter of Intent has been issued by Bank of Baroda (on behalf of the lenders) declaring the company as the successful bidder in the relation to the acquisition of all assets of Reliance Home Finance.\r\nThe company had submitted a bid of Rs 2,911 crore (which includes Rs 24 crore as deferred interest) to financial creditors subject to the terms and conditions of the bid Document which has been approved by the lenders at their meeting held on June 19, 2021.\r\nWe believe that the acquisition of RHFL, a reputed lending franchise to affordable housing and housing segments make our company a significant player in diversified financial services, Authum Investment said in the release.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '21-06-2021_09-37-19__87029__Investment.jpg'),
(29, '21/06/2021~:~09:39:58~:~5015502697', 'Samsung sets up display unit in Uttar Pradesh', 'Electronics major Samsung has completed the construction of the display manufacturing unit that is shifted from China to Noida in Uttar Pradesh, a release said on Sunday.\r\nA delegation of electronics major Samsung led by the company\'s Southwest Asia President & CEO Ken Kang called upon Uttar Pradesh Chief Minister Yogi Adityanath on Sunday.\r\nThe delegation said that owing to the better industrial environment and investor-friendly policies, Samsung decided to establish the Display Manufacturing Unit, which was located in China, in Noida, and the work of establishing it has been completed, an official release said.\r\nThe delegation mentioned that the construction work displays the commitment towards India and to make Uttar Pradesh a manufacturing hub, it said. During the meeting with the delegation, the chief minister said that Samsung\'s Noida factory is a classic example of success of the \'Make in India\' programme, and added that this will help the youth of the state to get employment in the state.\r\nAdityanath assured the delegation that the state government will continue to extend help to the Samsung company in future as well.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:53:04--3100090745', '23-06-2021_06-05-22__88381__samsung.jpg'),
(30, '21/06/2021~:~09:45:50~:~2300932200', 'Jet Airways plans to start operations within six months of NCLT approval', 'Jet Airways is planning to start operations within six months of approval from the National Company Law Tribunal (NCLT), CNBC-TV18 has reported.\r\nThe Kalrock-Jalan consortium, the new owners of the airline, is in talks with the government about availability of slots, sources told the news channel. The carrier is open to alternating slots on a plus/minus 15 basis.\r\nJet Airways is also in talks with Airbus and Boeing for fleet expansion under a five-year plan, the report said.', '21/06/2021-:-09:20:18-:-9610164623', '21 Jun, 2021', '19/06/2021-05:01:33--7026815768', '21-06-2021_09-45-50__89105__Jet-Airways.jpg'),
(31, '22/06/2021~:~10:23:19~:~1348608438', 'U.S. shares plan to allocate 55 million vaccines from its stockpile', 'The Biden administration, on June 21, announced how it would allocate 55 million of the 80 million doses from its vaccine supply to other countries. It is unclear how many doses India will receive in this second allocation.\r\nThe administration already outlined its plans to share the first 25 million doses of its stockpile both bilaterally and via COVID-19 Vaccines Global Access, abbreviated as COVAX — an international coalition to distribute vaccines globally. Three quarters of the 80 million is being shared via COVAX and one quarter is being directly. Of the 80 million, 60 million are AstraZeneca vaccines, not yet approved for use in the U.S.\r\nOf the 55 million doses, 41 million will be shared via COVAX. Of this, approximately 14 million will go to Asian countries, including India, some 10 million for Africa (coordinated by the African Union) and approximately 16 million for Latin American countries. Another 14 million doses will be shared “with regional priorities and other recipients”, the White House statement said. This includes African, Asian, Eastern European and South American countries as well as three South Asian countries – Afghanistan, Bangladesh and Pakistan. The specific number of vaccines will be determined and shared as the administration works through logistical and regulatory specifics for each region, the White House said.\r\nAt the G7 in the U.K. last week, President Joe Biden announced that the U.S. would purchase and donate 500 million doses of the Pfizer-BioNTech vaccine to low and middle-income countries. The G7 also committed to provide a total of 1 billion vaccine doses from this summer onwards. The World Health Organisation (WHO) has estimated that the world needs 11 billion vaccines to respond to end the pandemic.', '22/06/2021-:-10:21:19-:-3449234041', '22 Jun, 2021', '19/06/2021-05:01:33--7026815768', '22-06-2021_10-23-19__57644__Virus-Outbreak-Biden.jpg'),
(40, '23/06/2021~:~04:11:14~:~7385041639', 'History tells us Himalayas hold key to controlling Asia; India must continue to be wary of China', 'In future whatever happens inside Tibet may matter for the Indian security environment and also that of Asia as well.For the past few years, the People\'s Liberation Army (PLA) has upgraded its high-tech weapons and conducted a series of live-fire military exercises along the Himalayan borders and in Tibet. For Instance, Global Times reported on 5 January, 2020 that “China\\\'s latest weapons including the Type 15 tank and the new 155-millimeter vehicle-mounted Howitzer were deployed in Southwest China\'s Tibet Autonomous Region as the People\'s Liberation Army (PLA) began a first round of exercises in 2020”.After Xi Jinping came to power, a major reorganisation of the PLA was carried out in 2015 and later in February 2016, the seven military regions were reorganised into five theatre commands. During the official flag-conferring ceremony held in Beijing on 1 February, 2016, Xi, also chairman of the Central Military Commission (CMC), \"urged the theate commands to improve their ability to command and strengthen joint command and action to complete the tasks of routine combat readiness and military actions\".Since then, there have been different intensive military exercises which also involved joint military exercises between different theatre commands, including the Western Theatre Command, which overlooks the security of East Turkestan (Xinjiang) and Tibet. All this centralisation of the command system indicates that China is planning to create a new front in the Indo-Tibet border.', '22/06/2021-:-10:21:19-:-3449234041', '23 Jun, 2021', '19/06/2021-05:01:33--7026815768', '23-06-2021_04-11-14__17746__M.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `website_name` varchar(100) DEFAULT NULL,
  `logo` varchar(500) NOT NULL,
  `footer_dec` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`website_name`, `logo`, `footer_dec`) VALUES
('NEWS SITE', '23-06-2021_05-05-59__19509__New Project.jpg', '©Copyright 2021 News | Powered by <a href=\"https://tathagatabandyo.github.io/Programming-Tutorial/\">Tathagata Bandyopadhyay</a>');

-- --------------------------------------------------------

--
-- Table structure for table `user_t`
--

CREATE TABLE `user_t` (
  `numbering` int(11) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_t`
--

INSERT INTO `user_t` (`numbering`, `user_id`, `first_name`, `last_name`, `username`, `password`, `role`) VALUES
(5, '19/06/2021-05:01:33--7026815768', 'Tathagata', 'Bandyopadhyay', 'tathagatabandyo', '0be995e3652dcd42c7d606a1ee6d98da', 1),
(10, '19/06/2021-05:53:04--3100090745', 'Jonty', 'Banerjee', 'jontybanerjee', '25f9e794323b453885f5181f1b624d0b', 0),
(23, '20/06/2021-10:00:04--2808095767', 'sam', 'roy', 'sam123', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(21, '20/06/2021-12:08:42--6392356527', 'demo', 'demo', 'demo123', '856fc81623da2150ba2210ba1b51d241', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `numbering_catrgory` (`numbering`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD UNIQUE KEY `numbering_post` (`numbering`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD UNIQUE KEY `logo` (`logo`);

--
-- Indexes for table `user_t`
--
ALTER TABLE `user_t`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `no` (`numbering`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `numbering` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `numbering` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `user_t`
--
ALTER TABLE `user_t`
  MODIFY `numbering` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
