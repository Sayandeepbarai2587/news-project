<footer class="bg-primary text-white text-center p-3">
    <span>&copyCopyright 2021 News | Powered by Tathagata Bandyopadhyay</span>
</footer>