<?php
    $hostname = "http://".$_SERVER["SERVER_NAME"]."/php/phptu/148-163(NEWS_PROJECT_CMS)";
    $conn = mysqli_connect($_SERVER["SERVER_NAME"],"root","","news_site") or die("<h1><Connection Error/h1>");
?>